import 'package:flutter/material.dart';
import 'package:emfa/blotter.dart';
import 'package:emfa/login.dart';
import 'package:emfa/MetaData/MetaDataUI.dart';
import 'package:emfa/master_detail/master_detail_container.dart';


void main() => runApp(OMS());

class OMS extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      theme: new ThemeData(
        primarySwatch: Colors.lightGreen,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('OMS'),
        ),
        body: MasterDetailContainer(),
      ),
    );
  }
}
