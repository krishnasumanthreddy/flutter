import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:csv/csv.dart';
import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:emfa/blotter_models.dart';


class Blotter extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _BlotterState();
  }
}

class _BlotterState extends State {
  var result;
  
  Future<String> getSWData(String uri) async {
    var res = await http
        .get(Uri.encodeFull(uri), headers: {"Accept": "application/json"});

    var resBody = json.decode(res.body);
    for (var ob in resBody['results']) {
      sw.add(Starwars(
          name: ob['name'],
          model: ob['model'],
          manufacturer: ob['manufacturer']));
    }
    setState(() {
      data = resBody['results'];
      url = resBody['next'];
    });
    return 'Success';
  }


  
  @override
  void initState() {
    print('init state in blotter state');
    getSWData(url);
    //readFile();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print('build state in blotter state');
    // TODO: implement build
    var tablecol;
    if(filterApplied)
   tablecol  = dataTableBuild(filterSW);
    else
    tablecol  = dataTableBuild(sw);

    var cols = tablecol.columns.where((c) => c.label == c.label).toList();
    List<Filter> filters = new List<Filter>();
    for (var col in cols) {
      Text dt = col.label;
      
      filters.add(Filter(columnName: dt.data, filterText: ""));
    }

    Widget filterwidg = Column(
      children: filters
          .map((filter) => Row(
                children: <Widget>[
                  Text(filter.columnName),
                  Expanded(
                    child: TextField(
                      onEditingComplete:(){} ,
                      onSubmitted: (value) {
                        hm[filter.columnName] = value;
                        print(hm.toString());
                      },
                    ),
                  )
                ],
              ))
          .toList(),
    );
    var children2 = <Widget>[
      //tablebuildContainer(data),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: tablecol,
      ),
      Container(
        margin: EdgeInsets.all(10.0),
        child: RaisedButton(
          child: Text('load'),
          onPressed: () {
            //getapidata
            print('button on pressed');
            filterApplied= false;
            getSWData(url);
            print('button on pressed released');
          },
        ),
      )
    ];
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          decoration: ShapeDecoration(
            color: Colors.lightGreen[100],
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(20.0),
              ),
            ),
          ),
          //color: Colors.green,
          margin: const EdgeInsets.all(30.0),
          padding: const EdgeInsets.all(20.0),

          // decoration: new BoxDecoration(
          //     border: new Border.all(color: Colors.blueAccent)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Column(children: children2),
              // Column(children: children2),
              filterwidg,
              Container(child: RaisedButton(child: Text("Apply Filters"),
              onPressed: (){
              ApplyFilters(sw,hm);
              setState(() {
               filterApplied = true; 
              });
                             }
                             ),)
                           ],
                         ),
                       ),
                     ),
                   );
                 }
               
                 Container tablebuildContainer(List data) {
                   return Container(
                       //   child: Center(
                       child: Table(
                           border: TableBorder.all(),
                           children: data
                               .map(
                                 (element) => TableRow(children: [
                                   TableCell(
                                     child: Text(element['name']),
                                   ),
                                   TableCell(
                                     child: Text(element['model']),
                                   ),
                                   TableCell(
                                     child: Text(element['manufacturer']),
                                   ),
                                   TableCell(
                                     child: Text(element['manufacturer']),
                                   ),
                                   TableCell(
                                     child: Text(element['manufacturer']),
                                   ),
                                   // TableCell(
                                   //   child: Text(element['manufacturer']),
                                   // ),
                                   // TableCell(
                                   //   child: Text(element['manufacturer']),
                                   // ),
                                 ]),
                               )
                               .toList()));
                   //   ),
                   // );
                 }
               // #endregion
               
                 DataTable dataTableBuild(List<Starwars> sw) {
                   int columnindex;
                   return DataTable(
                     sortAscending: true,
                     sortColumnIndex: 0,
                     columns: <DataColumn>[
                       DataColumn(
                         label: Text("name"),
                         numeric: false,
                         onSort: (i, b) {
                           columnindex = i;
                           print("$i $b");
                           setState(() {
                             sw.sort((a, b) => a.name.compareTo(b.name));
                           });
                         },
                         tooltip: "name of the character",
                       ),
                       DataColumn(
                         label: Text("model"),
                         numeric: false,
                         onSort: (i, b) {
                           print("$i $b");
                           columnindex = i;
                           setState(() {
                             sw.sort((a, b) => a.model.compareTo(b.model));
                           });
                         },
                         tooltip: "model of the character",
                       ),
                       DataColumn(
                         label: Text("manufacturer"),
                         numeric: false,
                         onSort: (i, b) {},
                         tooltip: "Manufacturer of the character",
                       )
                     ],
                     rows: sw
                         .map(
                           (swchar) => DataRow(
                              cells: <DataCell>[
                             DataCell(Text(swchar.name)),
                             DataCell(Text(swchar.model)),
                             DataCell(Text(swchar.manufacturer)),
                           ]),
                         )
                         .toList()
                         ,
               // rows: <DataRow>[
               // DataRow(cells: <DataCell>data.map((ojb) => )
               // ],
                   );
                 }

     void ApplyFilters(List<Starwars> sw, HashMap<String,String> hm)
    {
      filterSW.clear();
        for (var item in sw) {
          if(item.name.contains(hm["name"]) && item.model.contains(hm["model"])&& item.manufacturer.contains(hm["manufacturer"]))
          {
            filterSW.add(item);
          }
        }
    }

  }
               
              


class Blotte extends StatelessWidget {
  var result;
  Blotte() {}

  Future<String> readFile() async {
    final input = new File('assets/trades.txt');
    //final fields =  input.transform(new CsvToListConverter()).toList();
    String values = await input.readAsString();

    result = const CsvToListConverter().convert(values.toString());

    //result = res;
    return values;
  }

  @override
  Widget build(BuildContext context) {
    var values = readFile();

    // print(res);
    // List<List<String>> strres = new List<List<String>>();
    // for (var item in res) {
    //   List<String> castItem = new List<String>();
    //   for (var i in item) {
    //      String ci = i;
    //   }
    // }
    //List<List<String>> strlist =  <List<List<String>>> res;
    var res1 = [
      ['1', '2', '3'],
      ['4', '5', '7']
    ];

    // TODO: implement build
    return Table(
        border: TableBorder.all(),
        children: result
            .map(
              (list) => TableRow(
                  children: list
                      .map((element) => TableCell(
                            child: Text(element.toString()),
                          ))
                      .toList()),
            )
            .toList());
  }
}
